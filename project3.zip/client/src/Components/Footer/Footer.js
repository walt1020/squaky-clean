import React, { Component } from 'react';
import './Footer.css';

class Footer extends Component {
  render() {
    return (
      <div className="footer" >
        
        <p><strong>Sqeaky Clean</strong> | 511 Clean Water Rd. | Durham, NC | 919-555-1234</p> 

      </div>
    );
  }
}

export default Footer;
