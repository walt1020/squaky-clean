# squaky-clean
An app that lets you schedule a car wash from anywhere, any time. 
