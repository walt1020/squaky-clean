module.exports = {
	Customer: require("./customer"),
	Technician: require("./technician"),
	Appointment: require("./appointment")
}